package com.example.lisa;

import java.io.IOException;
import java.util.Set;
import java.util.UUID;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button i1;
    Button i2;
    Button i3;
    Button i4;
    Button i5;
    TextView t1;
    WebView maeView;

    String address = null , name=null;

    BluetoothAdapter myBluetooth = null;
    BluetoothSocket btSocket = null;
    Set<BluetoothDevice> pairedDevices;
    static final UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        i1=findViewById(R.id.btnOn);
        i2=findViewById(R.id.btnOff);
        i3=findViewById(R.id.btnleft);
        i4=findViewById(R.id.btnright);
        i5=findViewById(R.id.btnstop);
        maeView =findViewById(R.id.mView);

        maeView.setWebViewClient(new WebViewClient());
        maeView.loadUrl("https://www.zoom.us");





        try {setw();} catch (Exception e) {}
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setw() throws IOException
    {
        t1=(TextView)findViewById(R.id.textView1);
        bluetooth_connect_device();


        i1.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                led_on_off("1");
            }
        });

        i2.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                led_on_off("4");
            }
        });


        i3.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                led_on_off("2");
            }
        });


        i4.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                led_on_off("3");
            }
        });

        i5.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                led_on_off("5");
            }
        });

    }


    @SuppressLint("HardwareIds")
    private void bluetooth_connect_device() throws IOException
    {
        try
        {
            myBluetooth = BluetoothAdapter.getDefaultAdapter();
            address = myBluetooth.getAddress();
            pairedDevices = myBluetooth.getBondedDevices();
            if (pairedDevices.size()>0)
            {
                for(BluetoothDevice bt : pairedDevices)
                {
                    address=bt.getAddress().toString();name = bt.getName().toString();
                    Toast.makeText(getApplicationContext(),"Connected", Toast.LENGTH_SHORT).show();

                }
            }

        }
        catch(Exception we){}
        myBluetooth = BluetoothAdapter.getDefaultAdapter();//get the mobile bluetooth device
        BluetoothDevice dispositivo = myBluetooth.getRemoteDevice(address);//connects to the device's address and checks if it's available
        btSocket = dispositivo.createInsecureRfcommSocketToServiceRecord(myUUID);//create a RFCOMM (SPP) connection
        btSocket.connect();
        try { t1.setText("BT Name: "+name+"\nBT Address: "+address); }
        catch(Exception e){}
    }

    public void onClick(View v)
    {
        try
        {

        }
        catch (Exception e)
        {
            Toast.makeText(getApplicationContext(),e.getMessage(), Toast.LENGTH_SHORT).show();

        }

    }

    private void led_on_off(String i)
    {
        try
        {
            if (btSocket!=null)
            {

                btSocket.getOutputStream().write(i.toString().getBytes());
            }

        }
        catch (Exception e)
        {
            Toast.makeText(getApplicationContext(),e.getMessage(), Toast.LENGTH_SHORT).show();

        }

    }

}
